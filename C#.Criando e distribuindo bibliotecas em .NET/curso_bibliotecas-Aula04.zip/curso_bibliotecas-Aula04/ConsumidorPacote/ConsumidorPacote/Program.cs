﻿using bytebank_GeradorChavePix;

Console.WriteLine(GeradorPix.GetChavePix());
